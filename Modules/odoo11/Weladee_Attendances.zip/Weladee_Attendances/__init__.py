# -*- coding: utf-8 -*-
from . import models
from . import weladee_pb2_grpc
from . import weladee_pb2
from . import odoo_pb2
from . import odoo_pb2_grpc
from . import weladee_employee
from . import weladee_attendance
